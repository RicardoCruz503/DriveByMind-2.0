/*
 * File: gp_RPSSVEP_initialize.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56
 */

#ifndef __GP_RPSSVEP_INITIALIZE_H__
#define __GP_RPSSVEP_INITIALIZE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "gp_RPSSVEP_types.h"

/* Function Declarations */
extern void gp_RPSSVEP_initialize(void);

#endif

/*
 * File trailer for gp_RPSSVEP_initialize.h
 *
 * [EOF]
 */
