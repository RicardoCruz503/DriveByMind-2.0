/*
 * File: abs.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56
 */

#ifndef __ABS_H__
#define __ABS_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "gp_RPSSVEP_types.h"

/* Function Declarations */
extern void b_abs(const emxArray_creal_T *x, emxArray_real_T *y);

#endif

/*
 * File trailer for abs.h
 *
 * [EOF]
 */
