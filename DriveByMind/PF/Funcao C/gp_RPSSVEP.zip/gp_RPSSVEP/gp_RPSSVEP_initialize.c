/*
 * File: gp_RPSSVEP_initialize.c
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56
 */

/* Include Files */
#include "gp_RPSSVEP.h"
#include "gp_RPSSVEP_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void gp_RPSSVEP_initialize(void)
{
}

/*
 * File trailer for gp_RPSSVEP_initialize.c
 *
 * [EOF]
 */
