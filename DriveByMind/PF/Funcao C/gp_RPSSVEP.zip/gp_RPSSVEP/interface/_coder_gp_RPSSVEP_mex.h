/*
 * File: _coder_gp_RPSSVEP_mex.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56
 */

#ifndef ___CODER_GP_RPSSVEP_MEX_H__
#define ___CODER_GP_RPSSVEP_MEX_H__

/* Include Files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "_coder_gp_RPSSVEP_api.h"

/* Function Declarations */
extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
  mxArray *prhs[]);

#endif

/*
 * File trailer for _coder_gp_RPSSVEP_mex.h
 *
 * [EOF]
 */
