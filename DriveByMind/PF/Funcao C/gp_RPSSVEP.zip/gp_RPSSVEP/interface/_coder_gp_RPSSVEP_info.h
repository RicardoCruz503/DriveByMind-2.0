/* 
 * File: _coder_gp_RPSSVEP_info.h 
 *  
 * MATLAB Coder version            : 2.8 
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56 
 */

#ifndef ___CODER_GP_RPSSVEP_INFO_H__
#define ___CODER_GP_RPSSVEP_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_gp_RPSSVEP_info.h 
 *  
 * [EOF] 
 */
