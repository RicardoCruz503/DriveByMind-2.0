/*
 * File: rdivide.h
 *
 * MATLAB Coder version            : 2.8
 * C/C++ source code generated on  : 11-Sep-2015 21:01:56
 */

#ifndef __RDIVIDE_H__
#define __RDIVIDE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "gp_RPSSVEP_types.h"

/* Function Declarations */
extern void rdivide(const emxArray_real_T *x, double y, emxArray_real_T *z);

#endif

/*
 * File trailer for rdivide.h
 *
 * [EOF]
 */
